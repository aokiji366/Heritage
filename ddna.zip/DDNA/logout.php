<?php

include("session.php");
include("connection.php"); 

$username = $_SESSION['username'];
    
        header("location:index.php");
   
   





?>