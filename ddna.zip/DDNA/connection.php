
<?php


$con = mysqli_connect("localhost","root","","ddna_voting");


?> 