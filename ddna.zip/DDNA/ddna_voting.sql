-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2019 at 10:17 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ddna_voting`
--

-- --------------------------------------------------------

--
-- Table structure for table `contestant`
--

CREATE TABLE `contestant` (
  `id` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL,
  `id_num` bigint(13) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact_no` varchar(10) NOT NULL,
  `user_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contestant`
--

INSERT INTO `contestant` (`id`, `name`, `surname`, `id_num`, `email`, `contact_no`, `user_id`) VALUES
(1, 'jackson', 'kambule', 1234567890123, 'jackson.k47@gmail.com', '0724966578', 4),
(2, 'xolani', 'jetmi', 6701094822091, 'xolani@gmail.com', '0712243653', 12),
(3, 'senzo', 'atmost', 9708095678087, 'senzo@gmail.com', '0724966578', 13);

-- --------------------------------------------------------

--
-- Table structure for table `voter`
--

CREATE TABLE `voter` (
  `id` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL,
  `id_num` int(13) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact_no` int(10) NOT NULL,
  `user_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voter`
--

INSERT INTO `voter` (`id`, `name`, `surname`, `id_num`, `email`, `contact_no`, `user_id`) VALUES
(5, 'sanele', 'sithole', 2147483647, 'sanelesithole001@gmail.com', 724966578, 9),
(6, 'sbusiso', 'sithole', 2147483647, 'sbusiso.sithole@adaptit.co.za', 812471082, 10),
(7, 'busisiwe', 'machai', 2147483647, 'busisiwe@care.co.za', 831237766, 11);

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `vote_no` int(10) NOT NULL,
  `vote_date` varchar(10) NOT NULL,
  `voter_id` int(10) NOT NULL,
  `party_id` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`vote_no`, `vote_date`, `voter_id`, `party_id`) VALUES
(6, '2019-09-20', 6, 'TBS/19-NLQ'),
(7, '2019-09-20', 6, 'TBS/19-XHD'),
(8, '2019-09-20', 7, 'TBS/19-JTY'),
(9, '2019-09-24', 5, 'TBS/19-NLQ'),
(12, '2019-09-25', 6, 'TBS/19-WNJ'),
(13, '2019-09-25', 5, 'TBS/19-WNJ');

-- --------------------------------------------------------



-- --------------------------------------------------------

--
-- Table structure for table `party`
--

CREATE TABLE `party` (
  `party_id` varchar(15) NOT NULL,
  `party_name` varchar(20) NOT NULL,
  `party_description` varchar(300) NOT NULL,
  `contestant_id` int(10) NOT NULL,
  `image` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tender`
--

INSERT INTO `party` (`party_id`, `party_name`, `party_description`, `contestant_id`) VALUES
('TBS/19-JAI', 'UFC', 'The tender is to provide  tourist with B&B ', 1),
('TBS/19-JTY', 'HWD', 'The bid is to supply hospital across Gauteng forthe next 2 years', 1),
('TBS/19-NLQ', 'ITS', 'ABSA is looking for company to supply IT Equipment for our new branch and other upcoming branch for the next 5 years.If interested please place your bid and the highest will be awarded', 1),
('TBS/19-WNJ', 'ERT', 'We invite IT Companies to make a bid to be our contract mantainance for the next 2 years .', 1),
('TBS/19-XHD', 'TRE' ,'Department of Labour is looking for a Software Development company who is going to implement the Departments payroll system as the current has been rejected based on many problems.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `role` varchar(10) NOT NULL,
  `createdAt` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `createdAt`) VALUES
(4, 'Admin', 'password', 'Contestant', '2020-05-21'),
(9, 'ZumaJ', 'password', 'Voter', '2020-08-22'),
(10, 'SimphiweD', 'password', 'Voter', '2020-08-22'),
(11, 'BusiMc', 'password', 'Voter', '2020-08-23'),
(12, 'jetmi', 'password', 'Contestant', '2020-09-21'),
(13, 'atmost', 'password', 'Contestant', '2020-09-21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contestant`
--
ALTER TABLE `contestant`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `voter`
--
ALTER TABLE `voter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`vote_no`),
  ADD KEY `bidder_id` (`voter_id`),
  ADD KEY `tender_no` (`party_id`);

--
-- Indexes for table `party`
--
ALTER TABLE `party`
  ADD PRIMARY KEY (`party_id`),
  ADD KEY `admin_id` (`contestant_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contestant`
--
ALTER TABLE `contestant`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `voter`
--
ALTER TABLE `voter`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `vote_no` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;


--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contestant`
--
ALTER TABLE `contestant`
  ADD CONSTRAINT `const_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `voter`
--
ALTER TABLE `voter`
  ADD CONSTRAINT `voter_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `votes`
--
ALTER TABLE `votes`
  ADD CONSTRAINT `vote_ibfk_1` FOREIGN KEY (`voter_id`) REFERENCES `voter` (`id`),
  ADD CONSTRAINT `vote_ibfk_2` FOREIGN KEY (`party_id`) REFERENCES `party` (`party_id`);

--
-- Constraints for table `party`
--
ALTER TABLE `party`
  ADD CONSTRAINT `party_ibfk_1` FOREIGN KEY (`contestant_id`) REFERENCES `contestant` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
