﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
       
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            SqlCommand command;
            SqlDataAdapter dataReadere;
            String sql;
            SqlConnection con;

            con = new SqlConnection("Data Source=sqlserver;Initial Catalog=Heritagetab;Integrated Security=True");
            try
            {
                con.Open();
                sql = "select *   FROM Participants ";
                command = new SqlCommand(sql, con);



            }
            catch (Exception)
            {

                MessageBox.Show("failed");
            }

            con.Close();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand command;
            SqlDataAdapter dataReadere;
            String sql;
            SqlConnection con;

            con = new SqlConnection("Data Source=sqlserver;Initial Catalog=Heritagetab;Integrated Security=True");
            try
            {
                con.Open();
                sql = "select *   FROM Participants ";
                command = new SqlCommand(sql, con);



            }
            catch (Exception)
            {

                MessageBox.Show("failed");
            }

            con.Close();
            this.Close();
        }
    }
}
